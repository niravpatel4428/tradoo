module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/app/components/NavItem/Button/Button.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// "use client";
// import React from "react";
// import Link from "next/link";
// import { IoArrowForward } from "react-icons/io5";
// export type ButtonVariant = "primarydefault" | "secondarydefault" | "contrastdefault";
// export type ButtonSize = "M" | "L";
// interface ButtonProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
//   label: string;
//   href: string;
//   variant?: ButtonVariant;
//   size?: ButtonSize;
//   trailingIcon?: boolean;
//   className?: string;
// }
// const Button: React.FC<ButtonProps> = ({
//   label,
//   href,
//   variant = "primarydefault",
//   size = "L",
//   trailingIcon = false,
//   className = "",
//   ...props
// }) => {
//   /** Variant styles */
//   const variantClasses: Record<ButtonVariant, string> = {
//     primarydefault: "bg-primary text-white hover:bg-[#101729]",
//     secondarydefault: "bg-secondary text-primary hover:bg-[#DADCE0]",
//     contrastdefault: "bg-white text-primary",
//   };
//   /** Base padding (with icon) */
//   const sizeClasses: Record<ButtonSize, string> = {
//     M: "pl-7 pr-1 py-1 text-base font-medium",
//     L: "pl-7 pr-1 py-1 text-lg font-semibold leading-5",
//   };
//   /** Padding when NO icon */
//   const noIconPaddingClasses: Record<ButtonSize, string> = {
//     M: "pl-7 pr-7 py-3",      // 👈 Your custom values for M without icon
//     L: "pl-8 pr-8 py-4.5",    // 👈 Your previous L values
//   };
//   /** Icon wrapper */
//   const iconBg =
//     variant === "primarydefault"
//       ? "bg-white text-[#101729]"
//       : "bg-[#1C1F23] text-white";
//   /** dynamic spacing */
//   const dynamicGap = trailingIcon ? "gap-7" : "gap-0";
//   /** apply no-icon padding per M/L size */
//   const extraPadding = trailingIcon ? "" : noIconPaddingClasses[size];
//   return (
//     <Link
//       href={href}
//       className={`
//         inline-flex items-center rounded-full transition-all duration-200
//         ${variantClasses[variant]}
//         ${sizeClasses[size]}
//         ${dynamicGap}
//         ${extraPadding}
//         ${className}
//       `}
//       {...props}
//     >
//       <span>{label}</span>
//       {trailingIcon && (
//         <span
//           className={`flex items-center justify-center w-12 h-12 rounded-full transition-all duration-200 ${iconBg}`}
//         >
//           <IoArrowForward size={22} />
//         </span>
//       )}
//     </Link>
//   );
// };
// export default Button;
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io5/index.mjs [app-ssr] (ecmascript)");
"use client";
;
;
;
const Button = ({ label, href, variant = "primarydefault", size = "L", trailingIcon = false, className = "", ...props })=>{
    /** Variant styles */ const variantClasses = {
        primarydefault: "bg-primary text-white hover:bg-[#101729]",
        secondarydefault: "bg-secondary text-primary hover:bg-[#DADCE0]",
        contrastdefault: "bg-white text-primary"
    };
    /** Icon bg + color per variant */ const iconVariantClasses = {
        primarydefault: "bg-white text-[#101729]",
        secondarydefault: "bg-primary text-white",
        contrastdefault: "bg-primary text-white"
    };
    /** Base padding */ const sizeClasses = {
        M: "pl-7 pr-1 py-1 text-base font-medium",
        L: "pl-7 pr-1 py-1 text-lg font-semibold leading-5"
    };
    /** Padding when NO icon */ const noIconPaddingClasses = {
        M: "pl-7 pr-7 py-3",
        L: "pl-8 pr-8 py-4.5"
    };
    /** dynamic spacing */ const dynamicGap = trailingIcon ? "gap-7" : "gap-0";
    /** apply no-icon padding */ const extraPadding = trailingIcon ? "" : noIconPaddingClasses[size];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
        href: href,
        className: `
        inline-flex items-center rounded-full transition-all duration-200
        ${variantClasses[variant]}
        ${sizeClasses[size]}
        ${dynamicGap}
        ${extraPadding}
        ${className}
      `,
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: label
            }, void 0, false, {
                fileName: "[project]/app/components/NavItem/Button/Button.tsx",
                lineNumber: 164,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            trailingIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `
            flex items-center justify-center w-12 h-12 rounded-full
            transition-all duration-200
            ${iconVariantClasses[variant]}
          `,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["IoArrowForward"], {
                    size: 22
                }, void 0, false, {
                    fileName: "[project]/app/components/NavItem/Button/Button.tsx",
                    lineNumber: 174,
                    columnNumber: 11
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/components/NavItem/Button/Button.tsx",
                lineNumber: 167,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/NavItem/Button/Button.tsx",
        lineNumber: 152,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = Button;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__1abce7c4._.js.map