(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/components/NavItem/Button/Button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// "use client";
// import React from "react";
// import Link from "next/link";
// import { IoArrowForward } from "react-icons/io5";
// export type ButtonVariant = "primarydefault" | "secondarydefault" | "contrastdefault";
// export type ButtonSize = "M" | "L";
// interface ButtonProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
//   label: string;
//   href: string;
//   variant?: ButtonVariant;
//   size?: ButtonSize;
//   trailingIcon?: boolean;
//   className?: string;
// }
// const Button: React.FC<ButtonProps> = ({
//   label,
//   href,
//   variant = "primarydefault",
//   size = "L",
//   trailingIcon = false,
//   className = "",
//   ...props
// }) => {
//   /** Variant styles */
//   const variantClasses: Record<ButtonVariant, string> = {
//     primarydefault: "bg-primary text-white hover:bg-[#101729]",
//     secondarydefault: "bg-secondary text-primary hover:bg-[#DADCE0]",
//     contrastdefault: "bg-white text-primary",
//   };
//   /** Base padding (with icon) */
//   const sizeClasses: Record<ButtonSize, string> = {
//     M: "pl-7 pr-1 py-1 text-base font-medium",
//     L: "pl-7 pr-1 py-1 text-lg font-semibold leading-5",
//   };
//   /** Padding when NO icon */
//   const noIconPaddingClasses: Record<ButtonSize, string> = {
//     M: "pl-7 pr-7 py-3",      // 👈 Your custom values for M without icon
//     L: "pl-8 pr-8 py-4.5",    // 👈 Your previous L values
//   };
//   /** Icon wrapper */
//   const iconBg =
//     variant === "primarydefault"
//       ? "bg-white text-[#101729]"
//       : "bg-[#1C1F23] text-white";
//   /** dynamic spacing */
//   const dynamicGap = trailingIcon ? "gap-7" : "gap-0";
//   /** apply no-icon padding per M/L size */
//   const extraPadding = trailingIcon ? "" : noIconPaddingClasses[size];
//   return (
//     <Link
//       href={href}
//       className={`
//         inline-flex items-center rounded-full transition-all duration-200
//         ${variantClasses[variant]}
//         ${sizeClasses[size]}
//         ${dynamicGap}
//         ${extraPadding}
//         ${className}
//       `}
//       {...props}
//     >
//       <span>{label}</span>
//       {trailingIcon && (
//         <span
//           className={`flex items-center justify-center w-12 h-12 rounded-full transition-all duration-200 ${iconBg}`}
//         >
//           <IoArrowForward size={22} />
//         </span>
//       )}
//     </Link>
//   );
// };
// export default Button;
__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/io5/index.mjs [app-client] (ecmascript)");
"use client";
;
;
;
;
const Button = (t0)=>{
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(24);
    if ($[0] !== "bba73b1e5d7c628859195b0b2587308e99823d54dd210f137a208da7e7620e49") {
        for(let $i = 0; $i < 24; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "bba73b1e5d7c628859195b0b2587308e99823d54dd210f137a208da7e7620e49";
    }
    let href;
    let label;
    let props;
    let t1;
    let t2;
    let t3;
    let t4;
    if ($[1] !== t0) {
        ({ label, href, variant: t1, size: t2, trailingIcon: t3, className: t4, ...props } = t0);
        $[1] = t0;
        $[2] = href;
        $[3] = label;
        $[4] = props;
        $[5] = t1;
        $[6] = t2;
        $[7] = t3;
        $[8] = t4;
    } else {
        href = $[2];
        label = $[3];
        props = $[4];
        t1 = $[5];
        t2 = $[6];
        t3 = $[7];
        t4 = $[8];
    }
    const variant = t1 === undefined ? "primarydefault" : t1;
    const size = t2 === undefined ? "L" : t2;
    const trailingIcon = t3 === undefined ? false : t3;
    const className = t4 === undefined ? "" : t4;
    let t5;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            primarydefault: "bg-primary text-white hover:bg-[#101729]",
            secondarydefault: "bg-secondary text-primary hover:bg-[#DADCE0]",
            contrastdefault: "bg-white text-primary"
        };
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    const variantClasses = t5;
    let t6;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = {
            primarydefault: "bg-white text-[#101729]",
            secondarydefault: "bg-primary text-white",
            contrastdefault: "bg-primary text-white"
        };
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    const iconVariantClasses = t6;
    let t7;
    if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            M: "pl-7 pr-1 py-1 text-base font-medium",
            L: "pl-7 pr-1 py-1 text-lg font-semibold leading-5"
        };
        $[11] = t7;
    } else {
        t7 = $[11];
    }
    const sizeClasses = t7;
    let t8;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = {
            M: "pl-7 pr-7 py-3",
            L: "pl-8 pr-8 py-4.5"
        };
        $[12] = t8;
    } else {
        t8 = $[12];
    }
    const noIconPaddingClasses = t8;
    const dynamicGap = trailingIcon ? "gap-7" : "gap-0";
    const extraPadding = trailingIcon ? "" : noIconPaddingClasses[size];
    const t9 = `
        inline-flex items-center rounded-full transition-all duration-200
        ${variantClasses[variant]}
        ${sizeClasses[size]}
        ${dynamicGap}
        ${extraPadding}
        ${className}
      `;
    let t10;
    if ($[13] !== label) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            children: label
        }, void 0, false, {
            fileName: "[project]/app/components/NavItem/Button/Button.tsx",
            lineNumber: 207,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[13] = label;
        $[14] = t10;
    } else {
        t10 = $[14];
    }
    let t11;
    if ($[15] !== trailingIcon || $[16] !== variant) {
        t11 = trailingIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: `
            flex items-center justify-center w-12 h-12 rounded-full
            transition-all duration-200
            ${iconVariantClasses[variant]}
          `,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$io5$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IoArrowForward"], {
                size: 22
            }, void 0, false, {
                fileName: "[project]/app/components/NavItem/Button/Button.tsx",
                lineNumber: 219,
                columnNumber: 14
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/app/components/NavItem/Button/Button.tsx",
            lineNumber: 215,
            columnNumber: 27
        }, ("TURBOPACK compile-time value", void 0));
        $[15] = trailingIcon;
        $[16] = variant;
        $[17] = t11;
    } else {
        t11 = $[17];
    }
    let t12;
    if ($[18] !== href || $[19] !== props || $[20] !== t10 || $[21] !== t11 || $[22] !== t9) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: href,
            className: t9,
            ...props,
            children: [
                t10,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/NavItem/Button/Button.tsx",
            lineNumber: 228,
            columnNumber: 11
        }, ("TURBOPACK compile-time value", void 0));
        $[18] = href;
        $[19] = props;
        $[20] = t10;
        $[21] = t11;
        $[22] = t9;
        $[23] = t12;
    } else {
        t12 = $[23];
    }
    return t12;
};
_c = Button;
const __TURBOPACK__default__export__ = Button;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_components_NavItem_Button_Button_tsx_df961a95._.js.map