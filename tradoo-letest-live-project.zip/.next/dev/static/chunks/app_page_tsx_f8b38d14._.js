(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_ec1c52de._.js",
  "static/chunks/node_modules_react-icons_io5_index_mjs_9bce8f6c._.js",
  "static/chunks/node_modules_react-icons_lib_844c6c50._.js",
  "static/chunks/_fc4e5200._.js"
],
    source: "dynamic"
});
