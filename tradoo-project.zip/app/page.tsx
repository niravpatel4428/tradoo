import Image from "next/image";
import NavItem from "./components/NavItem/NavItem";

export default function Home() {
  return (
    <>
      <div className="flex justify-center text-center">
        <NavItem label="Product" expandable={true} />
      </div>
    </>
  );
}
